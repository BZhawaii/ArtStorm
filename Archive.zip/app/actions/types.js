export const FILTER = 'FILTER';
export const FETCH_ART_SUCCESS = 'FETCH_ART_SUCCESS';
