import React from 'react';

class Parallax extends React.Component {
    render() {
        return (
          <div className="parallax-container">
            <div className="parallax"><img src="img/parallax1.png"/>
            </div>
          </div>
        );
    }
}

export default Parallax;
