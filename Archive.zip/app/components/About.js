import React from 'react';

const About = () =>
    <div>
        Hey! Thanks for using this example. If you like it, consider starring the repo :))
        <div>
            <iframe
                src="https://ghbtns.com/github-btn.html?user=jpsierens&repo=webpack-react-redux&type=star&size=large"
                frameBorder="0"
                allowTransparency="true"
                scrolling="0">
            </iframe>
        </div>
    </div>;


export default About;
